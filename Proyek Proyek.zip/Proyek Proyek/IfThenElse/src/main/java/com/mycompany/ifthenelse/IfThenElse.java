/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ifthenelse;

/**
 *
 * @author adiwi
 */
public class IfThenElse {

    public static void main(String[] args) {
        boolean isOn = false;
        
        if (isOn) {
            System.out.println("Menyalakan Lampu");
        } 
        else {
            System.out.println(("Kondisi tidak terpenuhi..."));
        }
    }
}
